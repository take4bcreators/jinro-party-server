'use client';

export default function Home(): JSX.Element {
  return (
    <>
      <h1>脱落</h1>
      <p>ゲーム終了までお待ち下さい...</p>
    </>
  );
}
