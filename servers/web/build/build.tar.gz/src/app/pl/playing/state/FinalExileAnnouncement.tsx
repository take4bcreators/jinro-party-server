export default function Home(): JSX.Element {
  return (
    <>
      <h1>投票結果</h1>
      <p>追放</p>
    </>
  );
}
