export default function Home(): JSX.Element {
  return (
    <>
      <h1>プレイヤー発表</h1>
      <p>
        <strong>モニターに注目！</strong>
      </p>
    </>
  );
}
