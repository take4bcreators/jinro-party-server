'use client';
import PageNightPhase from './NightPhase';

// DEBUG用
export default function Home(): JSX.Element {
  return (
    <>
      <PageNightPhase />
    </>
  );
}
