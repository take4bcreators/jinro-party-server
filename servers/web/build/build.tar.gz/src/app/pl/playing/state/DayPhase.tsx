export default function Home(): JSX.Element {
  return (
    <>
      <h1>昼のフェーズ</h1>
      <p>話し合いを開始してください</p>
    </>
  );
}
