export default function Home(): JSX.Element {
  return (
    <>
      <p>脱落しました</p>
      <p>ゲームが終了するまでお待ちください...</p>
    </>
  );
}
