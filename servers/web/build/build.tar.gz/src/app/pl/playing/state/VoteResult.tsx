export default function Home(): JSX.Element {
  return (
    <>
      <h1>モニターに注目！</h1>
    </>
  );
}
