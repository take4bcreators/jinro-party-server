export default function Home(): JSX.Element {
  return (
    <>
      <h1>WOLLFICE</h1>
      <p>ゲームマスターがゲームの設定を行っています。</p>
      <p>しばらくお待ちください...</p>
    </>
  );
}
