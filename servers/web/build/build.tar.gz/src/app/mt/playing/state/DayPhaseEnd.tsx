export default function Home(): JSX.Element {
  return (
    <>
      <h1>昼のフェーズ終了</h1>
      <p>話し合いを終了してください。</p>
    </>
  );
}
