export default function Home(): JSX.Element {
  return (
    <>
      <h1>役職決定</h1>
      <p>各自のスマホで確認してください</p>
    </>
  );
}
