export default function Home(): JSX.Element {
  return (
    <>
      <h1>昼のフェーズ開始</h1>
      <p>昼の時間になりました</p>
      <p>話し合いを開始してください。</p>
    </>
  );
}
