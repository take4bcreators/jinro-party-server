export default function Home(): JSX.Element {
  return (
    <>
      <h1>WOLFFICE</h1>
      <p>〜 募集締め切り 〜</p>
    </>
  );
}
