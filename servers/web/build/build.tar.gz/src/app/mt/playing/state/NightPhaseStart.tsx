export default function Home(): JSX.Element {
  return (
    <>
      <h1>夜のフェーズ</h1>
      <p>夜になりました</p>
    </>
  );
}
