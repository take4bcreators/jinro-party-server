export default function Home(): JSX.Element {
  return (
    <>
      <h1>ゲーム終了</h1>
    </>
  );
}
