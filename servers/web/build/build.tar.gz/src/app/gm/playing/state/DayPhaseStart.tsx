export default function Home(): JSX.Element {
  return (
    <>
      <h1>昼のフェーズ開始</h1>
    </>
  );
}
