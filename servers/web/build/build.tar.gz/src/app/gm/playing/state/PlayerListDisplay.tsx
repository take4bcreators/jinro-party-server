export default function Home(): JSX.Element {
  return (
    <>
      <h1>プレイヤー情報表示画面</h1>
      <p>プレイヤー情報表示画面中です...</p>
    </>
  );
}
