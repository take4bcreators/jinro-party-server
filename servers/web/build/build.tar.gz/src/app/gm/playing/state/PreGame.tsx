export default function Home(): JSX.Element {
  return (
    <>
      <h1>人狼パーティ</h1>
      <p>ようこそ</p>
      <p>Please Waiting...</p>
    </>
  );
}
