export default function Home(): JSX.Element {
  return (
    <>
      <h1>夜のフェーズ開始</h1>
    </>
  );
}
