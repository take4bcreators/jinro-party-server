export default function Home(): JSX.Element {
  return (
    <>
      <h1>夜のフェーズ終了</h1>
    </>
  );
}
