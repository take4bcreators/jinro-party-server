export default function Home(): JSX.Element {
  return (
    <>
      <h1>役職発表画面</h1>
      <p>役職発表画面中です...</p>
    </>
  );
}
