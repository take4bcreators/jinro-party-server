export default function Home(): JSX.Element {
  return (
    <>
      <p>Now Loading...</p>
    </>
  );
}
