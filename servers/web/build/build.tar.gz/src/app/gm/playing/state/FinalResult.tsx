export default function Home(): JSX.Element {
  return (
    <>
      <h1>結果発表</h1>
    </>
  );
}
