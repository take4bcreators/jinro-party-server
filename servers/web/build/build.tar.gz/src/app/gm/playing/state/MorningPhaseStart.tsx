export default function Home(): JSX.Element {
  return (
    <>
      <h1>朝になりました...</h1>
    </>
  );
}
