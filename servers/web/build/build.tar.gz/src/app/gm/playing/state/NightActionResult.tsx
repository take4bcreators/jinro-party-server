export default function Home(): JSX.Element {
  return (
    <>
      <h1>〇〇脱落</h1>
    </>
  );
}
