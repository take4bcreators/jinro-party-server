export default function Home(): JSX.Element {
  return (
    <>
      <h1>投票終了</h1>
    </>
  );
}
