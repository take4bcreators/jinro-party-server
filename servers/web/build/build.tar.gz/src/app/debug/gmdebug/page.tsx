'use client';

// import DayPhaseStart from '@/app/gm/playing/state/DayPhaseStart';

export default function Home(): JSX.Element {
  return <></>;
  //   return <DayPhaseStart />;
}
