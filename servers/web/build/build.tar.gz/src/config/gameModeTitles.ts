import { GameMode } from './gameMode';

export const GAME_MODE_TITLES = new Map<GameMode, string>([
  [GameMode.Normal, '通常モード'],
]);
